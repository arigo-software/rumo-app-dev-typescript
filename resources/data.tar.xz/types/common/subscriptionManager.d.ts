import EventEmitter from "events";
import type { RumoUrl } from "lib/rumoUrl";
export type SubscriptionTypes = 'full' | 'delta' | 'api';
export type SubsciptionOptions = {
    type?: SubscriptionTypes;
    provideHierarchyStatus?: boolean;
};
export interface ISubscriptionManager {
    subscribe(url: RumoUrl, options: SubsciptionOptions): AbstractSubscription;
    subscribe(url: RumoUrl, type: SubscriptionTypes): AbstractSubscription;
    unsubscribe(id: number | AbstractSubscription): void;
    close(): void;
}
export declare abstract class AbstractSubscription extends EventEmitter {
    abstract close(): void;
}
export interface UpdateInfo {
    url: string;
    subPath: string[];
    referer?: string;
    method: 'PUT' | 'DELETE';
}
export declare interface AbstractSubscription {
    /**
     *
     * @param event Event name
     * @param listener Event listener
     */
    on(event: 'update', listener: Listener): this;
    on(event: 'error', listener: ErrorListener): this;
    on(event: 'subscribed', listener: () => any): this;
    on(event: 'status', listener: (event: {
        status: string;
        active: boolean;
    }) => any): this;
    /**
     *
     * @param event Event name
     * @param listener Event listener
     */
    once(event: 'update', listener: Listener): this;
    once(event: 'error', listener: ErrorListener): this;
    once(event: 'subscribed', listener: () => any): this;
    once(event: 'status', listener: (event: {
        status: string;
        active: boolean;
    }) => any): this;
}
export type Listener = (
/**
 * subscription Data
 */
data: any, 
/**
 * only available on delta subscription
 */
info?: UpdateInfo) => any;
export type ErrorListener = (
/**
 * error thrown
 */
error: Error, 
/**
 * additional info
 */
info?: any) => any;
/**
 *
 * @param _data update data
 * @param _info subinfo
 */
declare function _dummy(_data: any, _info?: UpdateInfo): any;
export type Listener2 = typeof _dummy;
export {};
