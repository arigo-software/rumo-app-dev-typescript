import { Jsonify } from "lib/appDef";
import { Json } from "rumo-types/json";
export type ConversionFunction<Dst, Src> = (actual: Dst, val: Src) => Src extends Jsonify<Src> ? (Dst extends Jsonify<Dst> ? Dst : never) : never;
export type ConversionFunctionLookup<Src> = {
    [dst: string]: ConversionFunction<Json, Src>;
};
export type TTRuleColl = {
    [src: string]: ConversionFunctionLookup<Json>;
};
