export declare let DateTz: any;
