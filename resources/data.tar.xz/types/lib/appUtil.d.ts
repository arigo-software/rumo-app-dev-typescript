import bluebird from "bluebird";
import dispatchStream from "lib/dispatchRestInternalStream";
import { AppDefinition, AppHookResult, AppHookResultCallback, AppInstance, ArrayInput, Headers, HttpResult, Jsonify, NodeCallback, Request, RequestMethod, RestRequestFunction, RestRequestSyncFunction, SimpleMap } from "lib/appDef";
import { SubscriptionCallback } from "./SubscriptionHandler";
import { Json } from "rumo-types/json";
export type StreamResponse = Parameters<Parameters<typeof dispatchStream>[1]>[1];
type ResultType<R> = R extends StreamResponse ? R : HttpResult<R>;
type SubscriptionObject = {
    _subscriptions: {
        method: string;
        url: string;
        cb: SubscriptionCallback;
    }[];
    _restSubScriptions: {
        method: string;
        url: string;
        cb: SubscriptionCallback;
    }[];
};
/**
 * Make a node.js callback function from an async function which returns a promise.
 */
export declare const unpromisify: (func: import("lib/appDef").ArbitraryAsyncFunction) => (this: unknown, ...args: unknown[]) => void;
/*********************************
 * Check ifvalue is valid number *
 *********************************/
export declare function checkValue(value: number): void;
/***************************
 * Check which DPs changed *
 ***************************/
export declare function changedDPs(appDef: AppDefinition, request: Request): {};
type ExtractAppInstanceType<A> = A extends AppDefinition<infer T> ? T : never;
/**********************************
 * call update function for changed dps (async)
 * appDef : _module.exports of the app
 * request : update request
 * updateFunc : object with key - dp name
 *                          value - function to call
 *                                  signature as async update function(request, callback)
 * defaultFunc : function to call if no key from updateFunc match. signature see updateFunc
 */
export declare function callDpUpdate<A = AppDefinition>(appDef: A, updateFunc: {
    [ioName: string]: RestRequestFunction<ExtractAppInstanceType<A>>;
}, defaultFunc?: RestRequestFunction<ExtractAppInstanceType<A>>): (this: ExtractAppInstanceType<A>, request: Request, callback: AppHookResultCallback) => void;
export declare function createReturnValue(results: SimpleMap<AppHookResult> | AppHookResult[]): AppHookResult;
/**********************************
 * call update function for changed dps (sync)
 * appDef : _module.exports of the app
 * request : update request
 * updateFunc : object with key - dp name
 *                          value - function to call
 *                                  signature as sync update function(request)
 * defaultFunc : function to call if no key from updateFunc match. signature see updateFunc
 */
export declare function callDpUpdateSync(appDef: AppDefinition, updateFunc: {
    [ioName: string]: RestRequestSyncFunction;
}, defaultFunc?: RestRequestSyncFunction): (this: AppInstance, request: Request, callback: AppHookResultCallback) => void;
/**********************************
 * Connect App to backend objects *
 **********************************/
export declare function AppConnector(appThat: AppInstance): any;
/****************************
 * Simplified internal REST *
 ****************************/
export declare function httpRequest<R = Json>(method: RequestMethod, url: string, headers?: Headers, body?: R extends Jsonify<R> ? R : never): Request<R>;
export declare function httpPost(url: string, body: Json, header?: Headers): Request<Json>;
export declare function httpGet(url: string, header?: Headers): Request<Json>;
export declare function httpPut(url: string, body?: Json, header?: Headers): Request<Json>;
export declare function httpDelete(url: string, header?: Headers): Request<Json>;
export declare function post<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, callback: NodeCallback<ResultType<R>>): void;
export declare function post<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, headers: Headers, callback: NodeCallback<ResultType<R>>): void;
export declare function postAsync<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, headers?: Headers): bluebird<ResultType<R>>;
export declare function get<R = Json>(url: string, callback: NodeCallback<ResultType<R>>): void;
export declare function get<R = Json>(url: string, headers: Headers, callback: NodeCallback<ResultType<R>>): void;
export declare function getAsync<R = Json>(url: string, headers?: Headers): bluebird<ResultType<R>>;
export declare function put<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, callback: NodeCallback<ResultType<R>>): void;
export declare function put<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, headers: Headers, callback: NodeCallback<ResultType<R>>): void;
export declare function putAsync<R = Json, T = any>(url: string, body: T extends Jsonify<T> ? T : never, headers?: Headers): bluebird<ResultType<R>>;
declare function _delete<R = Json>(url: string, callback: NodeCallback<ResultType<R>>): void;
declare function _delete<R = Json>(url: string, headers: Headers, callback: NodeCallback<ResultType<R>>): void;
export { _delete as delete };
export declare function deleteAsync<R = Json>(url: string, headers?: Headers): bluebird<ResultType<R>>;
export declare function sendRequest<R = Json>(req: Request, callback: NodeCallback<ResultType<R>>): void;
export declare function sendRequestAsync<R = Json>(req: Request): bluebird<ResultType<R>>;
/****************************
 * Simplified exthernal QUIC REST *
 ****************************/
/**
 * @param {{host: string, port: number, user : string, password : string}} options
 * @param {string} url - Requested URL
 * @param {object=} headers - Optional request headers
 * @returns {Promise}
 * @description send QUIC GET request
 */
export declare function quicGet(options: Options, url: string, headers?: Headers): Promise<any>;
/**
 * @param {{host: string, port: number, user : string, password : string}} options
 * @param {string} url - Requested URL
 * @param {object=} headers - Optional request headers
 * @returns {Promise}
 * @description send QUIC DELETE request
 */
export declare function quicDelete(options: Options, url: string, headers?: Headers): Promise<any>;
/**
 * @param {{host: string, port: number, user : string, password : string}} options
 * @param {string} url - Requested URL
 * @param {object|stream} body - data to send
 * @param {object=} headers - Optional request headers
 * @returns {Promise}
 * @description send QUIC PUT request
 */
export declare function quicPut(options: Options, url: string, body: Json, headers?: Headers): Promise<any>;
/**
 * @param {{host: string, port: number, user : string, password : string}} options
 * @param {string} url - Requested URL
 * @param {object|stream} body - data to send
 * @param {object=} headers - Optional request headers
 * @returns {Promise}
 * @description send QUIC PUT request
 */
export declare function quicPost(options: Options, url: string, body: Json, headers?: Headers): Promise<any>;
interface Options {
    host: string;
    port: number;
    user: string;
    password: string;
}
/*********************
* Delete subscription *
*********************/
export declare function unsubscribe(that: SubscriptionObject): void;
/*********************
 * Delete Child Apps *
 *********************/
type Ids = number | number[] | null;
export declare function deleteIDs(id: SimpleMap<Ids>, callback: NodeCallback): void;
/*********************************
 *  restart app after powerfail  *
 *********************************/
export declare function restarter(appThis: AppInstance, dpExecutingName: string, triggerCB: NodeCallback): void;
interface SubscriptionItem {
    func: Function;
    discrim: number;
}
type SubscriptionList = SubscriptionItem[];
/*********************************
 *  subscriptions                *
 *********************************/
export declare class Subscriptions {
    subscriptions: {
        [id: string]: SubscriptionList;
    };
    restSubScriptions: {
        [method: string]: SubscriptionList;
    };
    constructor();
    close(): void;
    subscribe(url: string, func: SubscriptionCallback, discrim?: number): any;
    unsubscribe(url: string, func: SubscriptionCallback, discrim?: number): void;
    subscribeRestMethod(method: string, func: Function): void;
    unsubscribeRestMethod(method: string, func?: SubscriptionCallback): void;
}
export declare function getArrayValue<T = Json>(entry: ArrayInput[string]): T;
