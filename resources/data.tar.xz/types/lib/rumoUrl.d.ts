export declare class RumoUrl {
    private _orgUrl;
    private _decodedArr;
    private _encodedArr;
    private _id;
    private _fb;
    private _dp;
    private _dat;
    private _arrayElement;
    private _isDat;
    private _isRestDp;
    private _datIndx;
    private _isList;
    private _isIdUrl;
    private _hasRestPrefix;
    private _isWsUrl;
    private _ws;
    private _dev;
    constructor(url: string | string[]);
    private normalizeUrl;
    private calculateDecodedArray;
    isList(): boolean;
    /**
     *
     * @returns string escaped url
     */
    toUrlStr(opt?: Options): string;
    /**
     *
     * @returns string of id, fb, dp, dat
     */
    toString(): string;
    getDecodedArr(): string[];
    getEncodedArr(): string[];
    private analyzeType;
    getId(): string;
    /**
     *
     * @returns string wsname if possible
     */
    getWs(): string;
    /**
     *
     * @returns string devname if possible
     */
    getDev(): string;
    /**
     *
     * @returns string fbname if possible
     */
    getFb(): string;
    /**
     *
     * @returns string dpname if possible
     */
    getDp(): string;
    /**
     *
     * @returns path to FB as decoded URI component array
     */
    getFbPath(): string[];
    /**
     *
     * @returns path to DP as decoded URI component array
     */
    getDpPath(): string[];
    /**
     *
     * @returns string dat name or full dat value
     */
    getDat(fullVal?: boolean): string;
    private getFullDatVal;
    getArrayElement(): string;
    isDat(): boolean;
    isRestDp(): boolean;
    getRestDp(): string;
    isRestApiRequest(): boolean;
    unescape(str: string): string;
    escape(str: string): string;
    hasRestPrefix(): boolean;
}
export declare function escape(str: string): string;
export declare function unescape(str: string): string;
export declare function rqlEscape(str: string): string;
/**
* strictly encodes an URI component (RFC 3986)
* @param{String}str
*/
export declare function strictEncode(str: string): string;
export interface RequestStub {
    url?: string;
    rumoUrl?: RumoUrl;
}
export declare function addRumoUrlToRequest(req: RequestStub): boolean;
interface Options {
    restPrefix: boolean;
    explicitWs: boolean;
    idAddr: boolean;
}
export {};
