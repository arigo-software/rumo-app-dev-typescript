import { EventEmitter } from 'events';
import { NodeCallback } from './appDef';
type Event = {
    time: number;
    callback: NodeCallback;
    id: number;
};
declare class EventScheduler extends EventEmitter {
    id: number;
    events: Array<Event>;
    timeoutId: NodeJS.Timeout;
    scheduleEvent: NodeCallback;
    constructor(id: number, events: Array<Event>, timeoutId: NodeJS.Timeout);
    addEvent(date: Date, callback: NodeCallback): number;
    deleteEvent(eventId: number): void;
    getEvents(): Event[];
    static scheduleEvent(that: EventScheduler): (callback: NodeCallback) => void;
    static onEvent(that: EventScheduler): () => void;
    static callCB(that: EventScheduler): void;
    static onTimeChanged(that: EventScheduler): () => void;
    static scheduleWeekly(that: EventScheduler): () => void;
}
declare const eventScheduler: EventScheduler;
export = eventScheduler;
