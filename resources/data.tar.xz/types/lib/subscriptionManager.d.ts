import { RumoUrl } from "./rumoUrl";
import { DeprecatedAny, Request } from "lib/appDef";
import { AbstractSubscription, ISubscriptionManager, UpdateInfo, SubscriptionTypes, SubsciptionOptions } from 'common/subscriptionManager';
export declare class SubscriptionManager implements ISubscriptionManager {
    private index;
    private _subscriptions;
    constructor();
    subscribe(url: RumoUrl): Subscription;
    subscribe(url: RumoUrl, options: SubsciptionOptions): Subscription;
    subscribe(url: RumoUrl, type: SubscriptionTypes): Subscription;
    unsubscribe(id: number | Subscription): void;
    unregister(id: number): void;
    close(): void;
    private getNextId;
}
export declare class Subscription extends AbstractSubscription {
    private _manager;
    private _id;
    private _type;
    private _callback;
    private _wsStatusCallback?;
    private _rumoUrl;
    private _subscribeKey;
    private _closed;
    private _retryTimeout;
    private _isLocal;
    private _apiProcessor;
    private _urlString;
    private _provideHierarchyStatus?;
    constructor(manager: SubscriptionManager, url: RumoUrl, options: SubsciptionOptions, id: number);
    private getCallback;
    private subscribe;
    private subscribeApi;
    private _subscribeApi;
    private unsubscribeApi;
    close(): Promise<void>;
    isLocal(): boolean;
}
export declare interface Subscription {
    emit(event: 'update', data: any, info?: UpdateInfo): boolean;
    emit(event: 'error', error: Error, info?: any): boolean;
    emit(event: 'subscribed'): boolean;
    emit(event: 'status', data: {
        status: string;
        active: boolean;
    }): boolean;
}
type apiEndpointName = keyof typeof subscribeApiEndpointMapping;
declare const subscribeApiEndpointMapping: {
    fs: string;
    editor: string;
    binding: string;
    ws: string;
};
export declare function isSupportedApiProcessor(processor: string): processor is apiEndpointName;
export interface SubscribeApi {
    /**
     * @param path subpath
     * @param emit function to be called from the API subscription
     * @return subscription ID
     */
    subscribe(path: string, emit: (request: Request, data: DeprecatedAny) => void): string;
    /**
     * @param subscriptionId subscription ID returned by subscribe()
     */
    unsubscribe(subscriptionId: string): void;
}
export {};
