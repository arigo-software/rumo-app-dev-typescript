import bluebird from 'bluebird';
import fs from 'fs-extra';
import stream from 'stream';
import forge from 'node-forge';
import { Writable } from 'stream';
import { escape, unescape, rqlEscape } from 'lib/rumoUrl';
import type { Json, JsonObject } from "rumo-types/json";
import { EventEmitter } from 'events';
import { Jsonify, NodeCallback, NodeMultiCallback, ObjectDoc, Request, SimpleMap, SimpleObjectSubTree, SimpleSet, TagTree } from 'lib/appDef';
import type { ExecResult } from './_auxTypes';
/********
 * TIME
 ********/
declare function timestampToMsec(datestring: ConstructorParameters<typeof Date>[0]): number;
declare function timeStamp(date?: Date): string;
declare function getIsoLocaltime(timestamp: ConstructorParameters<typeof Date>[0], withMS: boolean): string;
/**********
 * STRING
 **********/
declare function endsWith(str: string, postfix: string): boolean;
declare function startsWith(str: string, prefix: string): boolean;
/**
 * Encodes a string to base64 using Node.js Buffer API
 */
declare function base64(input: string): string;
/**
 * Creates a Basic Authentication header value
 * @param username - The username
 * @param password - The password
 * @returns The complete Basic Auth header value: "Basic <base64>"
 */
declare function basicAuth(username: string, password: string): string;
/********
 * FILE
 ********/
/********
 * save Move
 ********/
declare function moveFile(source: string, target: string, callback: NodeCallback): void;
/********
 * save Copy
 ********/
declare function copyFile(source: string, target: string, callback?: NodeCallback): void;
declare function callScript(script: string, params: string[], callback?: NodeCallback): void;
/********
 * save Write
 ********/
declare function writeFile(filename: string, content: string | Buffer, options: BufferEncoding | fs.WriteFileOptions, callback: NodeCallback): void;
declare function writeFile(filename: string, content: string | Buffer, callback: NodeCallback): void;
declare function writeFile(filename: string, content: string | Buffer, options?: BufferEncoding | fs.WriteFileOptions): bluebird<void>;
/**
 * Simple writable stream that discards all data written to it.
 * Used to consume readable streams when the data is not needed, preventing memory leaks.
 * @note This replaces the previous dependency "dev-null".
 * @returns A writable stream that discards all data.
 */
declare function devNull(): stream.Writable;
/********
 * save createWriteStream
 ********/
type CreateWriteStreamOptions = (Parameters<typeof fs.createWriteStream>)[1];
declare function createWriteStream(filename: string, options?: BufferEncoding | CreateWriteStreamOptions): SaveWriteStream;
declare class SaveWriteStream extends stream.PassThrough {
    private filename;
    tmpFile: string;
    callEnd: {
        chunk: any;
        encoding: BufferEncoding;
        callback: (err?: Error) => void;
    };
    callEndReady: boolean;
    callClose: {
        err: Error;
    };
    connected: boolean;
    eventEmitter: EventEmitter;
    constructor(filename: string);
    on(event: string | symbol, listener: (...args: any[]) => void): this;
    once(event: string | symbol, listener: (...args: any[]) => void): this;
    removeListener(event: string | symbol, listener: (...args: any[]) => void): this;
    end(cb?: (err?: Error) => void): this;
    end(chunk: any, cb?: (err?: Error) => void): this;
    end(chunk: any, encoding: BufferEncoding, cb?: (err?: Error) => void): this;
    _callEnd(): void;
    private _handleListenerFn;
}
declare function readdirRecursive(prefix: string, includeDirs?: boolean, path?: string, result?: string[]): Promise<string[]>;
/** internal type for writable stream state */
type _WritableState = {
    ending?: boolean;
    ended?: boolean;
    finished?: boolean;
};
/*************************************************
 *
 * checking writable stream
 *
 *************************************************/
declare function isWriteStreamAlive(writeStream: Writable & {
    _writableState?: _WritableState;
}): boolean;
/**
 * efficiently read last N lines from a file
 */
declare function readLastLines(file: string, lineCount: number): Promise<string[]>;
/*************************************************
 *
 * readfile with conversion of encoding to utf-8
 *
 *************************************************/
declare function readFileSync(filename: string, encoding: BufferEncoding): string;
declare function readFile(filename: string, encoding: BufferEncoding, callback: NodeCallback): void;
/**
 * Ignores error code ENOENT, which happens when the file was removed
 * while processing the file list.
 */
declare function removeFilesStartingWith(dir: string, filePrefix: string, callback: NodeCallback): void;
declare function deleteDir(dir: string, callback: NodeCallback): void;
declare function deleteDir(dir: string, ignore: string[], callback: NodeCallback): void;
declare function deleteDir(dir: string, keepDir: boolean, ignore: string[], callback: NodeCallback): void;
declare class Visited<T> extends Set<T> {
    _stack: T[];
    constructor();
    checkAdd(obj: T): void;
    pop(): void;
}
declare function clone(obj: SimpleSet, visited?: Visited<unknown>): SimpleSet;
declare function clone<T extends Json>(obj: T, visited?: Visited<unknown>): T;
declare function clone(obj: any, visited?: Visited<unknown>): any;
/***************
 *
 * JSON Select
 *
 ***************/
declare function checkJsonSelect(jsonSelect: JsonSelect, obj: Json): boolean;
type JsonSelect = JsonObject | ((value: Json) => boolean) | {
    [key: string]: JsonSelect | Json | ((value: Json) => boolean);
};
/****************************
 *
 *  simple equals
 *  - only use for JSON objects
 *  - no prototype checks
 *
 ****************************/
declare function equals(a: unknown, b: unknown): boolean;
declare function diffJson(a: unknown, b: unknown, path?: string[]): any;
declare function pathExists(obj: {}, path: (string | number)[]): boolean;
declare function applyPathToObj<Json>(pathArray: string[], obj: Json): Json;
declare function ensureObj(parent: {}, path: (string | number)[] | string | number): void;
declare function getUniqueKeyFromObj(obj: SimpleMap<unknown>, newKey: string): string;
declare function setFragmentAtPath<T>(obj: Jsonify<T>, path: string[], fragment: unknown, createPath?: boolean): unknown;
/**
 * Deletes the object at a given path.
 * If the parent of the addressed path is empty AND a collapseValue is given,
 * then the parent object will be set to this value.
 */
declare function deleteObjectAtPath<T>(obj: Jsonify<T>, path: string[], collapseValue?: boolean): any;
type ObjectContext = {
    object?: any;
    exists?: boolean;
    parent?: any;
    key?: string;
};
declare function analyzeObjectAtPath<T>(obj: Jsonify<T>, path: string[]): ObjectContext | null;
declare function purgeObjectAtPath<T>(obj: Jsonify<T>, path: string[]): void;
/**
* deletes all direct child objects
* This is usefull when the object is shared by other objects.
* Always returns the object.
*/
declare function deleteAllProperties(obj: {}): {};
type TraverseFunction<T extends (string | number) = string> = (key: T, value: unknown, path: T[]) => boolean | void;
/*************************************************
 * traverseObj
 *
 * call fn for each property recursively.
 * Arrays are also traversed, with integer keys
 * signature:
 * boolean fn(key, value, path)
 * // key string or int
 * // value any type
 * // path is array of keys
 * Returning true will stop the complete traversal.
 * Returning false will stop the traversal on the current level.
 *************************************************/
declare function traverseObj<T extends (string | number) = string>(obj: any, fn: TraverseFunction<T>): void;
/******************************************************************************
 * Creates a new object with all keys mapped.
 * If parameter throwIfClash is set, then an exception
 * will be thrown if more than one key is mapped to the same resulting key.
 * If set to false it is last-wins.
 ******************************************************************************/
declare function mapObjKeys(obj: any, fn: (string: string) => string, throwIfClash?: boolean): any;
/**
* remove all lastUpdate properties from obj
*/
declare function removeLastUpdates(obj: any): any;
/***************************************
 * keys as propertyMap to boolean true
 ***************************************/
declare function keysAsMap(obj: any): {};
/***************
 * object diff
 ***************/
/***
 * returns
 * {
 *     common: {...}, // if available
 *     aOnly:  {...}, // if available
 *     bOnly:  {...}  // if available
 * }
 */
type KeyDiffReturn = {
    common?: any;
    aOnly?: any;
    bOnly?: any;
};
declare function objKeyDiff(a: any, b: any): KeyDiffReturn;
/********************************
 *
 *       Schema Utils
 *
 ********************************/
declare function isWholeSchemaObject(obj: ObjectDoc): boolean;
declare function isChannel(obj: ObjectDoc): boolean;
declare function isDevice(obj: ObjectDoc): boolean;
declare function isApp(obj: ObjectDoc): boolean;
declare function isDeviceType(type: string): boolean;
/**
 * A NI device has a type like the following:
 * /~/type/dev/DRIVER/NI
 * /~/type/dev/DRIVER/x/y/z/NI
 * /~/type/dev/DRIVER/NI/x/y/z
 */
declare function isNIDeviceType(type: string): boolean;
/**
 * Generic type checking.
 *
 * @param typeIn a type to be checked with a meta/type
 * @param typeCheck something like "/~/type/app/xy"; if trailing '/' then only derived types
 * @param derivedAllowed controls whether also derived types are allowed; default is true
 * @returns whether typeIn is of type typeCheck
 */
declare function isType(typeIn: string, typeCheck: string, derivedAllowed?: boolean): boolean;
declare function getTypeFromObj(obj: any): any;
/**************************
 * get baseType for type
 **************************/
declare function getBaseType(type: string): string;
declare function searchNode(callback: NodeCallback): void;
/**
 * asyncEvent
 *
 * calls the emit function of an eventEmitter asynchron
 * the next event is called after the previous event returns
 *  *
 * @param eventEmitter EventEmitter which emit should be called asynchron
 * @param event event which is emitted
 * @param callback is called after all emit calls returned
 *
 * The event is called with the additional parans added to this function and a callback function
 */
declare function asyncEvent(this: unknown, eventEmitter: EventEmitter, event: string | symbol, callback: NodeCallback, ...args: unknown[]): void;
/********
*
* async
*
********/
declare function whilst<T>(test: (param: T) => boolean, fn: (callback: NodeCallback<T>) => void, result: T, callback: NodeCallback<T>): void;
declare function whilst<T>(test: (param: T) => boolean, fn: (callback: NodeCallback<T>) => void, callback: NodeCallback<T>): void;
declare function doWhilst<T>(fn: (callback: NodeCallback<T>) => void, test: (param: T) => boolean, callback: NodeCallback<T>): void;
declare function until<T>(test: (param: T) => boolean, fn: (callback: NodeCallback<T>) => void, result: T, callback: NodeCallback<T>): void;
declare function until<T>(test: (param: T) => boolean, fn: (callback: NodeCallback<T>) => void, callback: NodeCallback<T>): void;
declare function doUntil<T>(fn: (callback: NodeCallback<T>) => void, test: (param: T) => boolean, callback: NodeCallback<T>): void;
/**
 * Waits for a promise to become fulfilled or rejected.
 * @param promise {Promise} promise optional promise to wait for.
 * @returns a new promise that is fulfilled when the optional promise argument
 *          is fulfilled or rejected
 */
declare function waitForPromise(promise: Promise<any>): bluebird<any>;
/**
 * Promise chain using a condition function (condFn). While condFn() returns true fn is called.
 * An exception will break the chain, rejecting the promise.
 * If fn itself returns a promise then it is chained (i.e. waited for).
 * @param condFn condition function
 * @param fn function that is called in each iteration
 * @returns Promise
 */
declare function promiseWhile(condFn: () => boolean, fn: () => Promise<any> | void | number): Promise<any>;
/**
 * Iterates through an array calling a function callback(item, ix, array) for each item.
 * If chunkSize is greater than 0, the synchronous iteration is decoupled by a delay of 1 ms.
 * Returns a Promise.
 */
declare function promiseArrayEach(array: any[], callback: NodeMultiCallback, chunkSize: number): bluebird<any>;
type CollectDataFromStreamRequestExt = {
    destroy?: () => void;
    destroyed?: boolean;
    __error?: {
        message?: string;
    };
};
declare function isStreamRequest(req: Partial<Request>): boolean;
declare function normalizeToSpacedUrl(url: string): string;
declare function escapeAdditionalMqtt(str: string): string;
declare function parseUrl(url: string): {
    hostname: any;
    port: any;
    path: any;
    http: boolean;
    https: boolean;
};
declare function sanitizeUrlName(name: string): string;
/**
 * Returns an array which is a distribution of the original one.
 * Elements of the original array are not cloned but assigned into the resulting array.
 * @param array array of which the distribution should be calculated
 * @param count max distribution count
 * @returns array of indexes
 */
declare function getDistribution<T>(array: T[], count: number): T[];
declare function matchWithPrefix(str: string, prefix: string, regex: string | RegExp): RegExpMatchArray;
/**
 * Searches recursive all files in a directory if the contains astring
 * @param dir base directory for search
 * @param pattern of the file name
 * @param string to search in the file
 * @returns Promise array of files
 */
declare function findFile(dir: string, pattern: RegExp, string: string): any;
declare function createCertificateFromCsr(csrPem: forge.pki.PEM, serverCertPem: Buffer, serverKeyPem: Buffer, maxYears?: number): string;
declare function createCertificateFromCsrDays(csrPem: forge.pki.PEM, serverCertPem: Buffer, serverKeyPem: Buffer, maxDays: number): string;
declare function parseHttpError(data: string): string;
declare class BooleanTree {
    private _lookup;
    constructor();
    /**
    * If the keys array is not yet set, then this method will modify the internal
    * lookup which is indicated by returning true. Otherwise false is returned and
    * nothing will be modified.
    * @return true
    */
    process(keys?: string[]): boolean;
    has(keys?: string[]): boolean;
    set(keys?: string[]): void;
    clear(keys?: string[]): void;
}
/**
 * Returns a promise that resolves after some time
 * @param t time to resolve in ms
 * @returns Promise<void>
 */
declare function delay(t: number): Promise<void>;
declare function getDefaultWsName(): string;
declare function restartRumo(): Promise<ExecResult>;
declare function rebootRumo(): Promise<ExecResult>;
declare function tagObjHasTag(tagObj: TagTree | SimpleObjectSubTree<true>, tags: string[]): boolean;
/**************************
 * exports
 **************************/
declare const _default: {
    timestampToMsec: typeof timestampToMsec;
    timeStamp: typeof timeStamp;
    getIsoLocaltime: typeof getIsoLocaltime;
    setInterval: any;
    clearInterval: any;
    delay: typeof delay;
    unpromisify: (func: import("lib/appDef").ArbitraryAsyncFunction) => (this: unknown, ...args: unknown[]) => void;
    endsWith: typeof endsWith;
    startsWith: typeof startsWith;
    base64: typeof base64;
    basicAuth: typeof basicAuth;
    copyFile: typeof copyFile;
    moveFile: typeof moveFile;
    readLastLines: typeof readLastLines;
    readFileSync: typeof readFileSync;
    readFile: typeof readFile;
    removeFilesStartingWith: typeof removeFilesStartingWith;
    deleteDir: typeof deleteDir;
    writeFile: typeof writeFile;
    createWriteStream: typeof createWriteStream;
    isWriteStreamAlive: typeof isWriteStreamAlive;
    readdirRecursive: typeof readdirRecursive;
    devNull: typeof devNull;
    clone: typeof clone;
    diffJson: typeof diffJson;
    equals: typeof equals;
    exists: (obj: unknown) => boolean;
    pathExists: typeof pathExists;
    applyPathToObj: typeof applyPathToObj;
    ensureObj: typeof ensureObj;
    getUniqueKeyFromObj: typeof getUniqueKeyFromObj;
    analyzeObjectAtPath: typeof analyzeObjectAtPath;
    setFragmentAtPath: typeof setFragmentAtPath;
    deleteObjectAtPath: typeof deleteObjectAtPath;
    purgeObjectAtPath: typeof purgeObjectAtPath;
    deleteAllProperties: typeof deleteAllProperties;
    keysAsMap: typeof keysAsMap;
    objKeyDiff: typeof objKeyDiff;
    traverseObj: typeof traverseObj;
    mapObjKeys: typeof mapObjKeys;
    removeLastUpdates: typeof removeLastUpdates;
    checkJsonSelect: typeof checkJsonSelect;
    isWholeSchemaObject: typeof isWholeSchemaObject;
    isChannel: typeof isChannel;
    isDevice: typeof isDevice;
    isApp: typeof isApp;
    isType: typeof isType;
    getTypeFromObj: typeof getTypeFromObj;
    getBaseType: typeof getBaseType;
    isDeviceType: typeof isDeviceType;
    isNIDeviceType: typeof isNIDeviceType;
    exec: (cmd: string, args: Array<string>, callback: NodeCallback<ExecResult>) => number;
    execAsync: (cmd: string, args?: Array<string>) => bluebird<ExecResult>;
    searchNode: typeof searchNode;
    whilst: typeof whilst;
    doWhilst: typeof doWhilst;
    until: typeof until;
    doUntil: typeof doUntil;
    promiseWhile: typeof promiseWhile;
    promiseArrayEach: typeof promiseArrayEach;
    waitForPromise: typeof waitForPromise;
    asyncEvent: typeof asyncEvent;
    collectDataFromStream: (req: Partial<Request> & CollectDataFromStreamRequestExt, maxSize: number | NodeCallback, returnBuffer?: boolean | NodeCallback, callback?: NodeCallback) => void;
    collectRawDataFromStream: (req: Partial<Request> & CollectDataFromStreamRequestExt, maxSize: number | NodeCallback, returnBuffer?: boolean | NodeCallback, callback?: NodeCallback) => void;
    collectDataFromStreamAsync: (req: Partial<Request>) => bluebird<unknown>;
    collectRawDataFromStreamAsync: (req: Partial<Request>) => bluebird<unknown>;
    isStreamRequest: typeof isStreamRequest;
    unescape: typeof unescape;
    escape: typeof escape;
    rqlEscape: typeof rqlEscape;
    escapeAdditionalMqtt: typeof escapeAdditionalMqtt;
    normalizeToSpacedUrl: typeof normalizeToSpacedUrl;
    parseUrl: typeof parseUrl;
    sanitizeUrlName: typeof sanitizeUrlName;
    callScript: typeof callScript;
    getDistribution: typeof getDistribution;
    matchWithPrefix: typeof matchWithPrefix;
    findFile: typeof findFile;
    restartRumo: typeof restartRumo;
    rebootRumo: typeof rebootRumo;
    parseHttpError: typeof parseHttpError;
    createCertificateFromCsr: typeof createCertificateFromCsr;
    createCertificateFromCsrDays: typeof createCertificateFromCsrDays;
    getDefaultWsName: typeof getDefaultWsName;
    tagObjHasTag: typeof tagObjHasTag;
    BooleanTree: typeof BooleanTree;
    tmpdir: string;
    tmpTemplate: string;
};
export = _default;
