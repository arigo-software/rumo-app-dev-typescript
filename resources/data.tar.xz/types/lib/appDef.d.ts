import bluebird from "bluebird";
import { Writable } from "stream";
import type { RumoUrl } from 'lib/rumoUrl';
import type { Json } from 'rumo-types/json';
import { Domain } from "domain";
import type { SchemaFragment } from "rumo-types/jsonSchemaV3";
export type { SchemaFragment };
import { Datapoint, DpCfgBase, DpDat, DpDynamicType, FbBase, TagTree } from "rumo-types/rumoSchema";
export * from "rumo-types/rumoSchema";
import { RequireOnlyOne, SimpleMap } from "rumo-types/base";
import type { SimpleSet } from "rumo-types/base";
export * from "rumo-types/base";
import type { ConversionFunctionLookup } from "common/typeTranslator";
export type GenericError = string | Error;
export type Jsonify<T> = T extends string | number | boolean | null ? T : T extends Array<infer U> ? Jsonify<U>[] : T extends Function ? never : T extends object ? {
    [K in keyof T]: Jsonify<T[K]>;
} : never;
/**
 * a node callback, with error as first parameter
 */
export type NodeSuccessCallback = (err?: GenericError) => void;
export type NodeCallback<T = any> = (err?: any, arg?: T) => void;
export type NodeMultiCallback = (err?: any, ...arg: any[]) => void;
export type NodeVoidCallback = (err?: any) => void;
export type DeprecatedAny = any;
export type ArbitraryObject = {
    [k: string]: any;
};
export type VoidFunction = () => void;
export type ArbitraryFunction = (...arg: any[]) => any | void;
export type ArbitraryVoidFunction = (...arg: any[]) => void;
export type ArbitraryAsyncFunction = (...arg: any[]) => Promise<any | void> | bluebird<any | void>;
export type AsyncFunction = (...arg: unknown[]) => Promise<unknown | void> | bluebird<unknown | void>;
export type AppHookResult = void | undefined | boolean | string | string[];
export type AppHookResultCallback = (err?: any, result?: AppHookResult) => void;
export type TagProcResultItem<T> = {
    url: string;
    uri: string;
    body: T;
};
export type TagProcResult<T> = TagProcResultItem<T>[];
export type TypeProcResult<T> = SimpleMap<T>;
export interface AppId {
    id: number;
    appType?: string;
    path: string;
    fb?: string;
    restDpNoSeries?: boolean;
}
export type RequestMethod = "GET" | "PUT" | "POST" | "DELETE" | "HEAD";
export interface Headers {
    Referer?: string;
    "rumo-delegate-sourcetype"?: string;
    /** @deprecated, instead use "rumo-delegate-sourcetype" */
    "x-rumo-delegate-sourcetype"?: string;
    "rumo-discriminator"?: string | number;
    "no-referer"?: string;
    "rumo-sourcebinding"?: string;
    /** internal REST allows arbitrary objects */
    [key: string]: string | any;
}
export interface HttpResult<T = any> {
    status?: number;
    body?: T extends Jsonify<T> ? T : never;
    headers?: SimpleMap<string>;
    extension?: {
        headers?: SimpleMap<string>;
    };
}
export type HttpResultCallback<T = Json> = (err?: unknown, result?: HttpResult<T>) => void;
/**
 * The request object used inside rumo.
 * At least a url and a method must be provided.
 */
export interface Request<BodyType = any> {
    url: string;
    rumoUrl?: RumoUrl;
    originalUrl?: string;
    decodeUrl?: string;
    path?: string[];
    method: RequestMethod;
    body?: BodyType extends Jsonify<BodyType> ? BodyType : never;
    /**
     * If set to true, there will be no need to clone
     * the body, because it will be passed on and there should be no more
     * references to the body at the sender.
     */
    passBody?: true;
    query?: SimpleMap<string>;
    originalQuery?: string;
    parsedQuery?: ArbitraryObject;
    headers?: Headers;
    /**
     * @FIXME
     * @deprecated This should very likely be refactored to be headers.referer
     */
    header?: {
        Referer: string;
    };
    /**
     * @FIXME
     * @deprecated This should very likely be refactored to be headers.referer
     */
    referer?: string;
    locale?: string;
    appId?: AppId;
    acceptStream?: boolean;
    client?: {
        authorized?: boolean;
    };
    noCache?: boolean;
    noAdmin?: boolean;
    noSeries?: boolean;
    loginDest?: string;
    ignoreUrlAuth?: boolean;
    fromAppFramework?: boolean;
    fromApp?: boolean;
    fromDatabase?: boolean;
    fromDriver?: boolean;
    fromWsProcessor?: boolean;
    driverRestart?: boolean;
    internalRequest?: boolean;
    requestId?: number | number[];
    convertData?: {
        space?: string;
        convertedUrl?: string;
        isLocalWs?: boolean;
        isLocalRequest?: boolean;
        isLocalDev?: boolean;
    };
    convertedPut?: string;
    loggedInUser?: string;
    onlyCheckPermission?: boolean;
    acceptResponseStream?: boolean;
    sessionID?: string;
    session?: {
        /**
         * set after valid credentials but before 2fa
         */
        __preLoginUser__?: string;
        loggedInUser: string;
        loginKey?: string;
        clientUserId?: string;
        noLoginUser?: boolean;
        destroy: (cb: NodeSuccessCallback) => void;
        authorization: unknown;
        loginToken: string;
        lang?: string;
        disableNoLoginUser?: boolean;
        maxAge?: number;
        expirationDate?: number;
    };
    cookies?: {
        [key: string]: string;
    };
    originAddress?: string;
    virtual?: boolean;
    jobPriority?: number;
    parsedData?: {
        key: number | string;
        path: string[];
    };
    timeStamp?: Date;
    lastUpdate?: string;
    noResult?: boolean;
    pollrate?: number;
    _streamHandled?: boolean;
    pipe?: (stream: Writable) => Writable;
    sourceRules?: ConversionFunctionLookup<Json>;
    sourceType?: string;
    forceDelete?: boolean;
    type?: string;
    dbOldFragment?: any;
    orgDeleteProperty?: string;
    deletedObj?: any;
    deletedElements?: string[];
    deletedType?: string;
    isFromDriver?: boolean;
    driverUrl?: string;
    doNotPropagateNewForward?: boolean;
    remoteCsrUser?: boolean;
    remoteUser?: string;
    userRights?: {
        [key: string]: UserRights;
    };
    onReleaseInitBlock?: (id: number) => void;
    on?: (event: string, callback: (data: any) => void) => void;
    once?: (event: string, callback: (data: any) => void) => void;
    newForward?: {
        src: string;
        dest: string;
    };
    updateTimeStamp?: {
        url: string;
        rumoUrl: RumoUrl;
    };
    restart?: DeprecatedAny;
    uniqueTimestamps?: boolean;
}
export type RequestIgnoreBody = Omit<Request, 'body'>;
export type UserRights = {
    allow: UserRight[];
    deny: UserRight[];
};
export type RightsData = {
    objType?: string;
    fbType?: string;
    fbTag?: string | string[];
    objTag?: string | string[];
    dpTag?: string | string[];
    type?: string | string[];
    indexHtml?: string;
    fs?: string[];
    ws?: SimpleSet;
};
export type UserRight = {
    regexp?: RegExp;
    methods?: {
        [method in RequestMethod]?: true;
    };
    data?: RightsData;
    elements?: {
        methods: {
            [method in RequestMethod]?: true;
        };
        data: RightsData;
    }[];
};
/**
 * a data point definition with more than only the type
 */
export interface FullDpDefinition extends SchemaFragment {
    /**
     * forced cfg/valueType
     */
    valueType?: string;
    /**
     * defines whether the the dat object (including the value) should be persisted
     */
    persistent?: boolean;
    /**
     * If true, then the data point is not visible in the project editor.
     * In the case of a driver DP, the DP will not be polled.
     */
    hidden?: boolean;
    /**
     * defines whether this DP value is required
     */
    required?: boolean;
    /**
     * an optional default for the value
     */
    default?: Json;
    /**
     * unit of data point value
     */
    unit?: string;
    /**
     * Determines whether the dat/value is an "array input" mapping source addresses to values.
     * The actual JSON type of the dat/value must be "object" in this case.
     */
    array?: boolean;
    tag?: TagTree;
    dynamicType?: DpDynamicType;
    cov?: boolean;
    cp?: boolean;
}
type ShortDpDefinition = string;
export type DpDefinition = FullDpDefinition | ShortDpDefinition;
type DpInterface = {
    [key: string]: DpDefinition;
};
export type Status = {
    offline?: true;
    error?: true;
    [key: string]: true;
};
export type CreateFunction<BodyType = Json> = (request: Request<BodyType>, callback: NodeCallback) => void;
export type CreateSyncFunction<BodyType = Json> = (request: Request<BodyType>) => void;
export type RestRequestFunction<T = AppInstance, BodyType = Json> = (this: T, req: Request<BodyType>, cb: AppHookResultCallback) => void;
export type RestRequestAsyncFunction<T = AppInstance, BodyType = Json> = (this: T, req: Request<BodyType>) => Promise<AppHookResult>;
export type RestRequestSyncFunction<T = AppInstance, BodyType = Json> = (this: T, req: Request<BodyType>) => AppHookResult;
export type RestRequestVoidFunction<T = AppInstance> = (this: T, req: Request, cb: NodeVoidCallback) => void;
export type RestRequestAsyncVoidFunction<T = AppInstance> = (this: T, req: Request) => Promise<void>;
export type RestRequestSyncVoidFunction<T = AppInstance> = (this: T, req: Request) => void;
export interface RestDpHttpResult extends HttpResult {
    /**
     * which datapoints have changed
     */
    changed?: AppHookResult;
}
export type RestDpResult = false | RestDpHttpResult;
export type RestDpResultCallback = (err?: unknown, result?: RestDpResult) => void;
export type RestDpRequestFunction<T = AppInstance> = (this: T, req: Request, cb: RestDpResultCallback) => void;
export type RestDefinition<T> = {
    GET?: RestDpRequestFunction<T>;
    PUT?: RestDpRequestFunction<T>;
    POST?: RestDpRequestFunction<T>;
    DELETE?: RestDpRequestFunction<T>;
    HEAD?: RestDpRequestFunction<T>;
    acceptStream?: boolean | AcceptStream;
};
export type RestInterface<T> = {
    [key: string]: RestInterface<T> | RestDefinition<T>;
};
export type AcceptStreamCallback = (acceptStream: boolean) => void;
export type AcceptStream = (request: Request, callback: AcceptStreamCallback) => void;
export interface AppDefinition<T = AppInstance> {
    input?: DpInterface;
    output?: DpInterface;
    inputOutput?: DpInterface;
    rest?: RestInterface<T>;
    callback?: true;
    callbackSync?: true;
    singleton?: boolean;
    undeletable?: boolean;
    initialize?: boolean;
    acceptStream?: boolean | AcceptStream;
    version?: string;
    updateOutputs?: string[];
    doNotDelayInputs?: boolean;
    restDpNoSeries?: boolean;
    allowNullValue?: boolean;
    list?: {
        read: CreateFunction;
    };
    create?: CreateFunction<FbBase>;
    createSync?: CreateSyncFunction<FbBase>;
    init?: RestRequestFunction<T, FbBase>;
    initSync?: RestRequestSyncFunction<T, FbBase>;
    update?: RestRequestFunction<T>;
    updateSync?: RestRequestSyncFunction<T>;
    read?: RestRequestFunction<T>;
    readSync?: RestRequestSyncFunction<T>;
    delete?: RestRequestFunction<T>;
    deleteSync?: RestRequestSyncFunction<T>;
    cmd?: RestRequestVoidFunction<T>;
    cmdSync?: RestRequestSyncVoidFunction<T>;
    stop?: RestRequestVoidFunction<T>;
    stopSync?: RestRequestSyncVoidFunction<T>;
    setUpdateDelay?: (delay?: DeprecatedAny) => void;
    schema?: SchemaFragment | ((type: string) => SchemaFragment);
    domain?: Domain;
}
export type CreateConstraint = RequireOnlyOne<AppDefinition, 'create' | 'createSync'>;
export type InitConstraint = RequireOnlyOne<AppDefinition, 'init' | 'initSync'>;
export type UpdateConstraint = RequireOnlyOne<AppDefinition, 'update' | 'updateSync'>;
export type DeleteConstraint = RequireOnlyOne<AppDefinition, 'delete' | 'deleteSync'>;
export type StopConstraint = RequireOnlyOne<AppDefinition, 'stop' | 'stopSync'>;
export type ScannerAppInstance = AppInstance<{
    scan: boolean;
    autoMember: string;
    startAddress: string;
    endAddress: string;
    devList: DeprecatedAny;
    found: DeprecatedAny;
    foundList: DeprecatedAny;
    blacklist: DeprecatedAny;
    existing: DeprecatedAny;
    count: number;
    progress: DeprecatedAny;
    executing: boolean;
    ready: boolean;
    error: boolean;
    population: number;
    devListInfo: DeprecatedAny;
    readsPerSec?: number;
}> & {
    _id: number;
    _subscriptions: DeprecatedAny;
};
export interface AppModule<ThisType = AppInstance, T extends AppDefinition<ThisType> = AppDefinition<ThisType>> {
    exports: T;
}
export type CrudFunctionName = "create" | "read" | "update" | "delete";
export type CrudFunction<BodyType = any> = (request: Partial<Request<BodyType extends Jsonify<BodyType> ? BodyType : never>>, callback: NodeCallback) => void;
export type ReadMacroFunction = (type: string, callback: NodeCallback) => void;
export interface Processor {
    create?: CrudFunction;
    read?: CrudFunction;
    head?: CrudFunction;
    update?: CrudFunction;
    delete?: CrudFunction;
    command?: (request: Request, instance: unknown, callback: NodeCallback) => void;
    acceptStream?: boolean | AcceptStream;
    readMacro?: ReadMacroFunction;
    updateFunc?: any;
    deleteFunc?: any;
    createApp?: (request: Request, callback: NodeCallback, instance: unknown) => void;
}
export interface ProcessorModule {
    exports: Processor;
}
/** TODO: convert to class */
export type AppInstance<DpProperties extends {
    [key: string]: unknown;
} = {}, InternalData = unknown> = DpProperties & {
    _updateStatus?: (msg: string) => void;
    callback?: <ThisType extends AppInstance<DpProperties, InternalData>, P extends unknown[] = unknown[]>(fn: (this: ThisType, ...args: [...P, AppHookResultCallback]) => void) => (() => void);
    callbackSync?: <ThisType extends AppInstance<DpProperties, InternalData>, P extends unknown[] = unknown[]>(fn: (this: ThisType, ...params: P) => AppHookResult) => (() => void);
    initialized?: (err?: NodeJS.ErrnoException) => boolean;
    setStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
    hasStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
    getStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
    deleteStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
    waitForInitialized?: (app: string, callback: NodeCallback) => void;
    getDpCfg?: (dpName: string, callback: NodeCallback<DpCfgBase>) => void;
    getDpValueType?: (dpName: string, callback: NodeCallback<string>) => void;
    _internalData?: InternalData;
};
export type DeprecatedAppInstance = AppInstance<{}> & {
    [key: string]: Datapoint | DeprecatedAny;
};
export type AppInstanceCallbackConstraint = RequireOnlyOne<AppDefinition, 'delete' | 'deleteSync'>;
export type LoggingFunction = (..._args: unknown[]) => void;
export interface Logging {
    trace: LoggingFunction;
    log: LoggingFunction;
    debug: LoggingFunction;
    info: LoggingFunction;
    warn: LoggingFunction;
    error: LoggingFunction;
}
export type ArrayInput = {
    [value: string]: DpDat;
};
