import { ArbitraryObject, ArbitraryVoidFunction } from "lib/appDef";
import type { SubscriptionCallback } from "lib/SubscriptionHandler";
interface Stat {
    subscriptions: {};
    nodes: number;
    depth: number;
    width: number;
    printable?: ArbitraryObject;
}
export default class Node {
    children: Map<string, Node>;
    callbacks: {
        data?: SubscriptionCallback[];
        noData?: SubscriptionCallback[];
        constData?: SubscriptionCallback[];
    };
    degree: number;
    subscribers: number;
    path: string[];
    constructor();
    has(s: string | string[], i?: number): any;
    get(s: string | string[], i?: number): Node;
    set(key: string, val: Node): void;
    delete(key: string): void;
    add(path: string[], cb: ArbitraryVoidFunction, key: string, i?: number): void;
    remove(path: string[], cb: ArbitraryVoidFunction, key?: string, i?: number): void;
    getPath(path: string[], collection: Node[], i?: number): Node;
    getDescendants(collection: Node[]): Node[];
    getList(path?: string[]): Node[];
    getStats(path?: string[], obj?: ArbitraryObject, stat?: Stat, depth?: number): Stat | '';
    toString(): any;
}
export {};
