import { AppInstance, Request, SimpleMap } from "lib/appDef";
import { JsonObject } from "rumo-types/json";
import type { Cmd } from "rumo-types/rumoSchema";
export type Command = Cmd;
export declare abstract class Commands {
    private objId;
    private that?;
    private runningCommands;
    constructor(objId: number, that?: any);
    close(): Promise<void>;
    onRequest(request: Request): Promise<void>;
    init(): Promise<SimpleMap<Command>>;
    private parseUrl;
    private onPutStateCommand;
    private onNewServiceCommand;
    protected abstract getCommandServiceClass(command: string): typeof ServiceCommand<AppInstance, any>;
    protected abstract getCommandStateClass(command: string): typeof StateCommand<AppInstance, any>;
}
declare abstract class BaseCommand<T extends AppInstance = AppInstance, A = any> {
    protected command: string;
    protected objId: number;
    protected arg: A;
    protected that: T;
    constructor(command: string, objId: number, arg: A, that: T);
    abstract start(caller: Caller): Promise<void>;
}
export type Caller = 'request' | 'init';
/*************************************************************************************************
 *  Service Command
 */
export declare abstract class ServiceCommand<T extends AppInstance = AppInstance, A = any> extends BaseCommand<T, A> {
    private _baseUrl;
    protected get baseUrl(): string;
    start(): Promise<void>;
    private onError;
    private onReady;
    protected abstract onExecute(): Promise<any>;
}
/*************************************************************************************************
 *  State Command
 */
export declare abstract class StateCommand<T extends AppInstance = AppInstance, A = any> extends BaseCommand<T, A> {
    private onCommandClose;
    private canceled;
    private processingState;
    private result;
    private progress;
    private detailedProgress;
    constructor(command: string, objId: number, arg: A, that: T, onCommandClose: () => void);
    close(): Promise<void>;
    start(caller: Caller): Promise<void>;
    _onRequest(request: Request, command: Command): Promise<void>;
    private cancelCalled;
    private updateCommand;
    private setProcessingState;
    protected abstract onStart(caller: Caller): Promise<void>;
    protected abstract onCancel(): Promise<void>;
    protected abstract onClose(): Promise<void>;
    protected setProgress(progress: number): void;
    protected setDetailedProgress(detailedProgress: JsonObject): void;
    protected onError(err: any): void;
    protected onReady(result: any): void;
}
export {};
