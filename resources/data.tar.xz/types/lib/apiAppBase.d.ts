import { AppDefinition, NodeCallback, RestDefinition, RestRequestFunction, FbBase, AppHookResultCallback } from "lib/appDef";
type ApiAppRestInterface<T> = {
    [key: string]: ApiAppRestInterface<T> | RestDefinition<T>;
};
declare const apiBase: {
    <T>(exports: ApiAppRestInterface<T> | RestDefinition<T>, inheritInit?: RestRequestFunction<T, FbBase>): AppDefinition<{
        _updateStatus?: (msg: string) => void;
        callback?: <ThisType extends /*elided*/ any, P extends unknown[] = unknown[]>(fn: (this: ThisType, ...args: [...P, AppHookResultCallback]) => void) => (() => void);
        callbackSync?: <ThisType extends /*elided*/ any, P_1 extends unknown[] = unknown[]>(fn: (this: ThisType, ...params: P_1) => import("lib/appDef").AppHookResult) => (() => void);
        initialized?: (err?: NodeJS.ErrnoException) => boolean;
        setStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
        hasStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
        getStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
        deleteStatus?: (state: string, dp?: string, callback?: NodeCallback) => void;
        waitForInitialized?: (app: string, callback: NodeCallback) => void;
        getDpCfg?: (dpName: string, callback: NodeCallback<import("rumo-types/rumoSchema").DpCfgBase>) => void;
        getDpValueType?: (dpName: string, callback: NodeCallback<string>) => void;
        _internalData?: unknown;
    }>;
    default: /*elided*/ any;
};
export = apiBase;
