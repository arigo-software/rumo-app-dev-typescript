type Info = {
    product: string;
    targetType: string;
    version: string;
    expectedImageVersion: string;
    imageVersion: string;
    targetVersion: string;
    nodeVersion: string;
    v8Version: string;
    opensslVersion: string;
    serialNo?: string;
    artNo?: string;
};
declare const info: Info;
export = info;
