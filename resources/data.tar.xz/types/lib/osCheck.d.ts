declare const _default: {
    isWindows: () => boolean;
    isLinux: () => boolean;
    isAndroid: () => boolean;
    isDocker: () => boolean;
    isWsl: () => boolean;
};
export default _default;
