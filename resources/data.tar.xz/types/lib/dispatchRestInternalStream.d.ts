import stream from 'stream';
import { Headers, NodeCallback, Request } from './appDef';
declare function dispatchStream(request: Request): StreamResponse;
declare function dispatchStream(request: Request, callback: NodeCallback<StreamResponse>): void;
export = dispatchStream;
declare class StreamResponse extends stream.PassThrough {
    writeHead: (status: number, headers: Headers) => void;
    status: number;
    headers: Headers;
    constructor();
}
