import { DeprecatedAny } from "./appDef";
declare class HttpError extends Error {
    status: number;
    code: string;
    message: string;
    isList: boolean;
    constructor(obj: DeprecatedAny, message?: DeprecatedAny, isList?: DeprecatedAny);
}
export { HttpError as Error };
interface Options {
    isList?: boolean;
}
export declare function errHandler(out: DeprecatedAny): (err: DeprecatedAny, opt?: Options) => {
    status: any;
    body: {
        error: {
            message: any;
            code: any;
        };
    } | {
        error: {
            message: any;
            code: any;
        };
    }[];
};
