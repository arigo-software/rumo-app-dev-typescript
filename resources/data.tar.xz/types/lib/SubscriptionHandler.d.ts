import Node from 'lib/nodes';
import { ArbitraryObject, ArbitraryVoidFunction, DeprecatedAny, HttpResultCallback, Request } from 'lib/appDef';
export type DataKey = "data" | "noData" | "constData";
export type SubscriptionCallback = (req?: Request, data?: any) => void;
export type ReadByKeyFunction = (key: string, req: Request, hotObj: boolean, callback: HttpResultCallback) => void;
export type Options = {
    keyObjMap?: ArbitraryObject;
    readByKey?: ReadByKeyFunction;
};
/**
* class for handling Subscriptions by discriminator and objekt keys
*/
export declare class SubscriptionHandler {
    m_list: {
        [discrim: string]: {
            [id: string]: Node;
        };
    };
    keyObjMap: {};
    readByKey: ReadByKeyFunction;
    constructor(opt?: Options);
    reinit(opt: Options): void;
    subscribe(key: string | number, dataKey: DataKey, callback: SubscriptionCallback, request?: Request): void;
    subscribe(key: string | number, dataKey: DataKey, discrim: number | string, callback: SubscriptionCallback, request?: Request): void;
    subscribe(key: string | number, dataKey: DataKey, discrim: number | string | SubscriptionCallback, callback?: SubscriptionCallback | Request, request?: Request): void;
    unsubscribe(key: string | number, discrim: number | string, callback: ArbitraryVoidFunction): void;
    call(key: string | number, data: DeprecatedAny, req: Request): void;
    getStats(): {};
}
