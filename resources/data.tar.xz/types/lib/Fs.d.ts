import fs from "fs-extra";
import stream from "stream";
import { DeprecatedAny, Request } from "lib/appDef";
interface MaybeConvertedPath {
    path?: string;
    orgPath: string;
}
interface ConvertedPath extends MaybeConvertedPath {
    path: string;
}
interface FdInfo extends ConvertedPath {
    created?: true;
    changed?: true;
}
type FdCollection = {
    [k: string]: FdInfo;
};
export type CreateReadStreamOptions = (Parameters<typeof fs.createReadStream>)[1];
export type CreateWriteStreamOptions = (Parameters<typeof fs.createWriteStream>)[1];
type PathCallback = (req: Request, path: string) => void;
export default class Fs {
    user: string;
    mapStaticType: boolean;
    fds: FdCollection;
    internalRequest: boolean;
    static readonly STAT: {
        MODE: {
            S_IFMT: number;
            S_IFSOCK: number;
            S_IFLNK: number;
            S_IFREG: number;
            S_IFBLK: number;
            S_IFDIR: number;
            S_IFCHR: number;
            S_IFIFO: number;
            S_ISUID: number;
            S_ISGID: number;
            S_ISVTX: number;
            S_IRWXU: number;
            S_IRUSR: number;
            S_IWUSR: number;
            S_IXUSR: number;
            S_IRWXG: number;
            S_IRGRP: number;
            S_IWGRP: number;
            S_IXGRP: number;
            S_IRWXO: number;
            S_IROTH: number;
            S_IWOTH: number;
            S_IXOTH: number;
        };
    };
    constructor(user: string, mapStaticType?: boolean, internalRequest?: boolean);
    open(path: string, mode?: string): Promise<number>;
    close(fd: number): Promise<void>;
    readdir(path: string): Promise<string[]>;
    readdirRecursive(prefix: string, includeDirs?: boolean, path?: string, result?: string[]): Promise<string[]>;
    stat(path: string): Promise<fs.Stats>;
    lstat(path: string): Promise<fs.Stats>;
    fstat(fd: number): Promise<fs.Stats>;
    readlink(path: string): Promise<string>;
    access(path: string, mode?: string): Promise<void>;
    /**
     * This method has issues and exists only for backward compatibility.
     * Use @see createReadStreamFunc instead.
     */
    createReadStream(path: string, options?: CreateReadStreamOptions): Promise<fs.ReadStream>;
    createReadStreamFunc(path: string, options?: CreateReadStreamOptions): Promise<() => fs.ReadStream>;
    readFile(path: string, options: {
        encoding?: string;
        flag?: string;
    }): Promise<string>;
    mkdir(path: string, options?: fs.Mode | fs.MakeDirectoryOptions): Promise<void>;
    mkdirs(path: string): Promise<void>;
    /**
     *
     * @param fd file-descriptor
     * @param data Data to write
     * @param arg1 offset:number
     * @param arg2 encoding:BufferEncoding|string / length:number
     * @param arg3 position:number
     * @returns
     */
    write(fd: number, data: any, arg1?: number, arg2?: DeprecatedAny, arg3?: DeprecatedAny): Promise<void>;
    /**
     * This method has issues and exists only for backward compatibility.
     * Use @see createWriteStreamFunc instead.
     */
    createWriteStream(path: string, options?: CreateWriteStreamOptions): Promise<stream.Writable>;
    createWriteStreamFunc(path: string, options?: {
        flags?: string;
        fd?: number;
    }): Promise<() => stream.Writable>;
    writeFile(path: string, data: string | Buffer, options?: fs.WriteFileOptions): Promise<void>;
    /**
     * This method works similar to the unix command 'touch'.
     * It will change the modification time of the file to now or creates it if allowCreate is true.
     * If the file does not exist and allowCreate is false, an error will be thrown.
     * This is useful to tell the system, that a files has been updated when the file was modifed by an external process.
     * The event is always a 'create'.
     */
    touch(path_: string, allowCreate?: boolean): Promise<void>;
    ensureFile(path: string): Promise<void>;
    ensureDir(path: string): Promise<void>;
    copy(srcPath: string, destPath: string, options?: fs.CopyOptions): Promise<void>;
    rename(oldPath: string, newPath: string, { overwrite }?: {
        overwrite?: boolean;
    }): Promise<void>;
    unlink(path: string): Promise<void>;
    remove(path: string): Promise<void>;
    rmdir(path: string): Promise<void>;
    symlink(target: string, path: string, type: fs.SymlinkType): Promise<void>;
    chmod(path: string, mode: fs.Mode): Promise<void>;
    fchmod(fd: number, mode: fs.Mode): Promise<void>;
    watch(path: string, options: {
        encoding?: BufferEncoding;
        persistent?: boolean;
        recursive?: boolean;
    }, listener: (event: string, filename: string | Buffer) => void): Promise<fs.FSWatcher>;
    static appendSlash(path: string): string;
    static subscribe(_path: string, mapStaticType: boolean | PathCallback, callback?: PathCallback): number;
    static unsubscribe(id: number | string): void;
}
export declare const webPrefix = "./web/";
export {};
