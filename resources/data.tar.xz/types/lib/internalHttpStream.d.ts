import stream from 'stream';
import { Headers, HttpResult, Request as RumoRequest } from './appDef';
import { DeprecatedAny } from './appDef';
import type { Json } from 'rumo-types/json';
export declare class Response extends stream.PassThrough implements HttpResult {
    status: number;
    extension: DeprecatedAny;
    __error?: Error;
    _sendHeaderNoDelay?: boolean;
    body: Json;
    constructor(options?: stream.TransformOptions);
    writeHead(status: number, headers?: Headers): void;
}
export declare class Request extends stream.PassThrough implements Partial<RumoRequest> {
    _streamHandled?: boolean;
    extension: DeprecatedAny;
    constructor(request?: RumoRequest, options?: stream.TransformOptions);
}
declare const _exports: {
    Response: typeof Response;
    Request: typeof Request;
};
export default _exports;
