import { Request } from './appDef';
import { RequestOptions } from 'https';
import { Response as HttpResponse } from 'lib/internalHttpStream';
import { Json } from 'rumo-types/json';
export interface HostOptions {
    host: string;
    port: number;
    user?: string;
    password?: string;
    customerId?: string;
}
type ExpandedRequest = Request & {
    noStream?: boolean;
};
declare function sendHttpsRequest(options: HostOptions | RequestOptions, request: ExpandedRequest): Promise<Json | HttpResponse>;
export default sendHttpsRequest;
